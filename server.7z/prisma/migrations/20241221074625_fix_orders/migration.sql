-- AlterTable
ALTER TABLE `productorder` ADD COLUMN `cost` INTEGER NOT NULL DEFAULT 0;
